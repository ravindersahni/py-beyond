__author__ = 'instancetype'

from reader.reader import Reader